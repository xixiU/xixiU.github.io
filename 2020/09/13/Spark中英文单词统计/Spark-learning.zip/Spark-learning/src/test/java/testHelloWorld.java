import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;
import com.hankcs.hanlp.tokenizer.StandardTokenizer;

import java.util.List;

public class testHelloWorld {
    public static void main(String[] args) {
        System.out.println(HanLP.segment("你好，欢迎使用HanLP汉语处理包！"));
        List<Term> termList = StandardTokenizer.segment("你好，欢迎使用HanLP汉语处理包");
        System.out.println(termList.iterator().toString());
//        System.out.println(termList.get(0).word);
//        termList.forEach(term -> {
//
//            System.out.println(term.word);
//        });
//        System.out.println(termList);
    }
}
